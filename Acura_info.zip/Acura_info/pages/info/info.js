// pages/info/info.js
// const util = require('../../utils/city.js')

Page({
  data: {
    litpic: '',
    username: '',
    phone: '',
    gender: '',
    model: '',
    background: '',
    items: [{
        name: '男',
        value: '男'
      },
      {
        name: '女',
        value: '女'
      }
    ],
    checked: true,
    cityindex: 0,
    multiArray: [], // [省[]，市[]]
    multiArray2: [], // [经销商]
    multiIndex: [0, 0, 0], // 选择序号
    province_name: "", //默认省份
    city_name: "", //默认城市
    jxs_name: "", //经销商
    showView: false,
  },

  //分享函数
  onShareAppMessage: function () {
    return {
      title: "I'M DIFFERENT.异行者",
      path: '/pages/index/index',
      imageUrl:'https://wx.weiyihui.cn/Acura_info/images/share.jpg'
    }
  },

  //单选框- 性别
  radioChange: function(e) {
    this.setData({
      gender: e.detail.value
    })
  },

  //姓名
  usernameChange: function(e) {
    this.setData({
      username: e.detail.value
    })
  },

  //手机号
  phoneChange: function(e) {
    this.setData({
      phone: e.detail.value
    })
  },

  //省切换
  bindMultiPickerColumnChange: function(e) {
    let that = this;
    console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    let num = e.detail.value;
    let column = e.detail.column;
    if (column == 0) {
      // 切换省
      that.setData({
        province_name: that.data.multiArray[0][num],
        multiIndex: [num, 0, 0],
      })
      that.loadCity(that.data.province_name)
    } else {
      // 切换市
      that.setData({
        city_name: that.data.multiArray[1][num],
        multiIndex: [that.data.multiIndex[0], num, 0],
      })
      that.loadCountry(that.data.city_name)
    }
  },
  // 经销商切换
  jxsChange: function(e) {
    let that = this;
    console.log('值为', e.detail.value);
    let num = e.detail.value;
    that.setData({
      jxs_name: that.data.multiArray2[num],
      multiIndex: [that.data.multiIndex[0], that.data.multiIndex[1], num],
    })
  },
 
  //获取省份，后端提供的省份接口地址
  loadProivnce() {
    let that = this;
    wx.request({
      url: 'https://wx.weiyihui.cn/Acura_info/index.php?ac=province',
      method: "post",
      data: {},
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'csrf-csrf': 'csrf-csrf',
        "Authorization": wx.getStorageSync('Authorization')
      },
      success: function(res) {
        let dataArray = res.data;

        that.setData({
          province_name: dataArray[0],
          multiArray: [dataArray, []],
        })

        //根据默认省，获取默认市
        that.loadCity(that.data.province_name)
      }
    })
  },

  //获取市级，后端提供的市级接口地址
  loadCity(province_name) {
    let that = this;
    wx.request({
      url: 'https://wx.weiyihui.cn/Acura_info/index.php?ac=city',
      method: "post",
      data: {
        province: province_name,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'csrf-csrf': 'csrf-csrf',
        "Authorization": wx.getStorageSync('Authorization')
      },
      success: function(res) {
        let dataArray = res.data;
        // 修改省市
        that.setData({
          city_name: dataArray[0],
          multiArray: [that.data.multiArray[0], dataArray],
          multiIndex: [that.data.multiIndex[0], 0, 0],
        })

        //根据默认市获取对应经销商
        that.loadCountry(that.data.city_name)
      }
    })
  },

  //获取经销商
  loadCountry(city_name) {
    let that = this;
    wx.request({
      url: 'https://wx.weiyihui.cn/Acura_info/index.php?ac=jxs',
      method: "post",
      data: {
        city: city_name,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'csrf-csrf': 'csrf-csrf',
        "Authorization": wx.getStorageSync('Authorization')
      },
      success: function(res) {
        let dataArray = res.data
        that.setData({
          multiArray2: dataArray,
          country_id: dataArray[0],
          jxs_name: dataArray[0],
          multiIndex: [that.data.multiIndex[0], that.data.multiIndex[0], 0],
        })
        that.search()
      }
    })
  },

  search() {
    //根据条件查询 
  },

  // 服务条款
  checkboxChange: function(e) {
    let that = this;
    if (e.detail.value == '') {
      that.data.checked = false
    } else {
      that.data.checked = true
    }
  },

  //阅读服务条款
  infoClause: function() {
    let that = this;
    that.setData({
      showView: that.data.showView = true
    })
  },

  //关闭阅读服务条款
  closeClause: function() {
    let that = this;
    that.setData({
      showView: that.data.showView = false
    })
  },

  onLoad: function(options) {
    //省市二级的默认渲染
    this.loadProivnce();

    //获取从列表页带过来的海报图片路径和车型
    let that = this;
    that.setData({
      litpic: options.url, // 海报
      model: options.model, // 车型
      background: options.background // 底图
    })
    console.log(decodeURIComponent(options.model))
  },

  // 提交
  getInfo: function(e) {
    let that = this;
    if (that.data.username == '' || that.data.phone == '' || that.data.gender == '') {
      wx.showModal({
        showCancel: false,
        title: '提示',
        content: '请填写完整信息'
      })
      return false;
    }
    // 检测手机号格式
    var telReg = !!that.data.phone.match(/^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/);
    //如果手机号码不能通过验证
    if (telReg == false) {
      wx.showModal({
        showCancel: false,
        title: '提示',
        content: '手机号不正确'
      })
      return false;
    }
    //服务条款
    if (!that.data.checked) {
      wx.showModal({
        showCancel: false,
        title: '提示',
        content: '请同意服务条款再进行提交'
      })
      return false;
    }

    //console.log(this.data.array[this.data.index]);
    //预约试驾留资信息
    wx.request({
      url: 'https://wx.weiyihui.cn/Acura_info/index.php?ac=info', //仅为示例，并非真实的接口地址
      data: {
        username: that.data.username, //姓名
        phone: that.data.phone, //手机号
        gender: that.data.gender, //性别
        province: that.data.province_name, //省份
        city: that.data.city_name, //城市
        agency: that.data.jxs_name, //经销商
        model: decodeURIComponent(that.data.model) //车型
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if (res.data.result) {
          wx.showModal({
            showCancel: false,
            title: '提示',
            content: "感谢您的信任 \n我们会尽快与您联系",
            success: function(res) {
              if (res.confirm) {
                wx.reLaunch({
                  url: '/pages/index/index'
                })
              }
            }
          })
        } else {
          if (res.data.error == 1) {
            wx.showModal({
              showCancel: false,
              title: '提示',
              content: '请填写正确信息'
            })
            console.log('参数不全');
          } else if (res.data.error == 2) {
            wx.showModal({
              showCancel: false,
              title: '提示',
              content: '请填写正确信息'
            })
            console.log('手机号码格式错误');
          } else if (res.data.error == 3) {
            wx.showModal({
              showCancel: false,
              title: '提示',
              content: '系统繁忙'
            })
            console.log('入库失败');
          } else if (res.data.error == 4) {
            wx.showModal({
              showCancel: false,
              title: '提示',
              content: '该号码已留资'
            })
            console.log('该号码已留资');
          }
        }
      }
    })
  },

})