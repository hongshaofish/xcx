// pages/info/info.js
const util = require('../../utils/city.js')
Page({
  data: {
    litpic: '',
    username: '',
    phone: '',
    gender: '',
    model:'',
    items: [
      { name: '男', value: '男'},
      { name: '女', value: '女'}
    ],
    checked: true,
    array: [],
    index: 0,
    city: [],
    cityindex: 0,
    showView: false
  },
  //返回首页
  // backIndex: function(){
  //   wx.navigateTo({
  //     url: '/pages/index/index'
  //   })
  // },
  //单选框- 性别
  radioChange: function (e) {
    this.setData({
      gender: e.detail.value
    })
    //console.log('radio发生change事件，携带value值为：', e.detail.value)
  },
  //姓名
  usernameChange: function(e){
    this.setData({
      username: e.detail.value
    })
    //console.log('username发生change事件，携带value值为：', e.detail.value)
  },
  //手机号
  phoneChange: function (e) {
    this.setData({
      phone: e.detail.value
    })
    //console.log('phone发生change事件，携带value值为：', e.detail.value)
  },
  // 省份
  bindPickerChange: function (e) {
    //console.log('picker发送选择改变，携带值为', this.data.array[e.detail.value])
   
    this.setData({
      index: e.detail.value,
      cityindex:0
    })

    var index = this.data.index;
    var provinces = util.provinces;
    var citys = util.citys;

    var citysArr = citys[provinces[index].id];
    //console.log(citysArr)

    var arr = [];
    for (var i = 0; i < provinces.length; i++) {
      arr.push(provinces[i].name);
    }

    var arr1 = [];
    for (var j = 0; j < citysArr.length; j++) {
      arr1.push(citysArr[j].name);
    }

    //console.log(citysArr)
    this.setData({
      array: arr,
      city: arr1
    })
  },
  //市
  bindcity: function (e) {
    //console.log('市：', this.data.city[e.detail.value])
    this.setData({
      cityindex: e.detail.value,
    })
  },
  // 服务条款
  checkboxChange: function (e) {
    let that = this;
    if (e.detail.value == '') {
      that.data.checked = false
    }
    else {
      that.data.checked = true
    }
  },
  //阅读服务条款
  infoClause: function(){
    let that = this;
    that.setData({
      showView: that.data.showView = true
    })
  },
  //关闭阅读服务条款
  closeClause: function(){
    let that = this;
    that.setData({
      showView: that.data.showView = false
    })
  },
  onLoad: function (options) {
    //省市二级的默认渲染
    var index = this.data.index;
    var provinces = util.provinces;
    var citys = util.citys;
    var citysArr = citys[provinces[index].id];
    var arr = [];
    for (var i = 0; i < provinces.length; i++) {
      arr.push(provinces[i].name);
    }

    var arr1 = [];
    for (var j = 0; j < citysArr.length; j++) {
      arr1.push(citysArr[j].name);
    }

    this.setData({
      array: arr,
      city: arr1
    })
    //获取从列表页带过来的海报图片路径和车型
    let that = this;
    that.setData({
      litpic: options.url,
      model: options.model
    })
  },
  // 提交
  getInfo: function(e){
    let that = this;
    if (that.data.username == '' || that.data.phone == '' || that.data.gender == ''){
      wx.showModal({
        showCancel: false,
        title: '提示',
        content: '请填写完整信息'
      }) 
      return false;
    }
    // 检测手机号格式
    var telReg = !!that.data.phone.match(/^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/);
    //如果手机号码不能通过验证
    if (telReg == false) {
      wx.showModal({
        showCancel: false,
        title: '提示',
        content: '手机号不正确'
      }) 
      return false;
    }
    //服务条款
    if (!that.data.checked){
      wx.showModal({
        showCancel: false,
        title: '提示',
        content: '请同意服务条款再进行提交'
      }) 
      return false;
    }

    //console.log(this.data.array[this.data.index]);
    //预约试驾留资信息
    wx.request({
      url: 'https://yidian.weiyihui.com.cn/Acura_info/index.php?ac=info', //仅为示例，并非真实的接口地址
      data: {
        username: that.data.username, //姓名
        phone: that.data.phone, //手机号
        gender: that.data.gender, //性别
        province: that.data.array[that.data.index], //省份
        city: that.data.city[that.data.cityindex], //城市
        model: decodeURIComponent(that.data.model) //车型
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if (res.data.result) {
          wx.showModal({
            showCancel: false,
            title: '提示',
            content: "感谢您的信任 \n我们会尽快与您联系",
            success: function (res) {
              if (res.confirm) {
                that.data.username= '';
                that.data.phone = '';
                that.data.gender = '';
                that.data.array[e.detail.value] = '';
                that.data.city[e.detail.value] = '';
                that.data.model = '';
                wx.navigateTo({
                  url: '/pages/index/index'
                })
              }
            }
          }) 
        } else{
          if (res.data.error == 1){
            wx.showModal({
              showCancel: false,
              title: '提示',
              content: '请填写正确信息'
            })
            console.log('参数不全');
          } else if (res.data.error == 2){
            wx.showModal({
              showCancel: false,
              title: '提示',
              content: '请填写正确信息'
            })
            console.log('手机号码格式错误');
          } else if (res.data.error == 3) {
            wx.showModal({
              showCancel: false,
              title: '提示',
              content: '系统繁忙'
            })
            console.log('入库失败');
          } else if (res.data.error == 4) {
            wx.showModal({
              showCancel: false,
              title: '提示',
              content: '该号码已留资'
            })
            console.log('该号码已留资');
          }
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})