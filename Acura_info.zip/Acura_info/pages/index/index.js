//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    list:[],
    flashs:[],
    tmer:null,
  },
  
  //分享函数
  onShareAppMessage: function () {
    return {
      title: "I'M DIFFERENT.异行者",
      path: '/pages/index/index',
      imageUrl: 'https://wx.weiyihui.cn/Acura_info/images/share.jpg'
    }
  },

  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    let that = this;

    //车型列表数据请求
    wx.request({
      url: 'https://wx.weiyihui.cn/Acura_info/index.php?ac=list', //仅为示例，并非真实的接口地址
      data: {},
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        that.setData({
          list: res.data.data,
          flashs: [
            'flash',
            '',
            '',
            '',
            '',
            '',
          ]
        })
        wx.hideLoading();
      }
    });
  },
  tapCar: function(e){
    let that = this;
    let url = e.currentTarget.dataset.url; // 海报
    let model = e.currentTarget.dataset.model; // 车型
    let background = e.currentTarget.dataset.background; // 底图

    // let f_index = e.currentTarget.dataset.index;
    // let flashs = that.data.flashs;
    // // 移除flah
    // flashs[f_index] = '';
    // that.setData({
    //   flashs: flashs
    // })
    // console.log(url, model)
    // 跳转到预约页面
    clearInterval(this.data.tmer);
    this.setData({
      tmer:null
    })
    wx.navigateTo({
      url: '/pages/info/info?url=' + url + '&model=' + encodeURIComponent(model) + '&background=' + background
    })
    
  },
  onShow: function () {
    this.setData({
      flashs: [
        'flash',
        '',
        '',
        '',
        '',
        '',
      ]
    });
    this.animation();
  },
  onUnload:function(){
    // clearInterval(this.data.tmer);
  },
  animation:function(){
    let that = this;
    let f_index = 0;
    this.data.tmer = setInterval(function () {
      let flashs = that.data.flashs;
      // 移除flah
      flashs[f_index] = '';
      flashs[f_index + 1] = 'flash';
      that.setData({
        flashs: flashs
      });
      f_index++;
      if (f_index > 5) {
        let flashs = that.data.flashs;
        f_index = 0;
        flashs[f_index] = 'flash';
        that.setData({
          flashs: flashs
        });
      }
      //console.log(f_index)
    }, 400)
  }
})
